package com.demo;

public class Bike implements Vehical{

	@Override
	public void move() {
		System.out.println("moving on a bike");	
	}

}
